<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - E-Commerce</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            flex-direction: column;
            text-align: center;
        }
        .btn {
            font-size: 1.2rem;
            padding: 10px 25px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Welcome to My E-Commerce Site</h1>
    <p>Manage your product listings easily with our simple dashboard.</p>
    <a href="<?php echo e(url('/products')); ?>" class="btn btn-light">Go to Product List</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecommerce_project\resources\views/home.blade.php ENDPATH**/ ?>