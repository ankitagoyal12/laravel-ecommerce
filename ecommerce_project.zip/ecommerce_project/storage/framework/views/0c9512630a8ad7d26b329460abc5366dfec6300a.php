<!DOCTYPE html>
<html>
<head>
    <title>Welcome to My Shop</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f1f3f6;
            text-align: center;
            padding: 100px;
        }
        h1 {
            font-size: 36px;
            color: #333;
        }
        a {
            padding: 12px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Welcome to My Laravel E-commerce App!</h1>
    <p>Click below to view available products</p>

    <a href="<?php echo e(route('products.index')); ?>">View Products</a>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecommerce_project\resources\views/welcome.blade.php ENDPATH**/ ?>