<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 30px;
            background: #f1f4f8;
        }

        .form-container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
            margin-top: 15px;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        img.preview {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }

        a.back {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        a.back:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Edit Product</h2>

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <label for="name">Product Name</label>
        <input type="text" name="name" id="name" value="{{ $product->name }}" required>

        <label for="description">Description</label>
        <textarea name="description" id="description" rows="3">{{ $product->description }}</textarea>

        <label for="price">Price (₹)</label>
        <input type="number" step="0.01" name="price" id="price" value="{{ $product->price }}" required>

        <label for="image">Change Image (optional)</label>
        <input type="file" name="image" id="image">

        @if ($product->image)
            <img src="{{ asset('storage/' . $product->image) }}" alt="Current Image" class="preview">
        @endif

        <button type="submit">Update Product</button>
    </form>

    <a href="{{ route('products.index') }}" class="back">← Back to Product List</a>
</div>

</body>
</html>
